var name = "Hannah"; 
var color = "blue"; 


var prompt= prompt("what is your name and your favorite color?");
var greeting = "My name is " +prompt;



document.querySelector(".name").innerHTML = greeting; 

